# IN HEAT / Clover Mod Menu

Made by Poklut. Built for the single-player game **IN HEAT**.

## Included files

- `IHLFNModMenu.dll` — the compiled mod.
- `MelonLoader-0.7.3-IN-HEAT-x64.zip` — the MelonLoader version used during development.
- `IHLFNModMenu-Source-Code.zip` — complete mod source and build guide.

## Installation

1. Close IN HEAT.
2. In Steam, right-click **IN HEAT**, choose **Manage**, then **Browse local files**.
3. Extract `MelonLoader-0.7.3-IN-HEAT-x64.zip` directly into the game folder—the folder containing `IN HEAT.exe`.
4. Start the game once. Wait for the title screen, then close it. This creates the `Mods` folder and finishes MelonLoader setup.
5. Copy `IHLFNModMenu.dll` into the game's `Mods` folder.
6. Start IN HEAT normally through Steam.

## Controls

- `F1` — show or hide the mod menu.
- Click menu buttons and checkboxes with the mouse.
- `F2` — emergency release for automated Sammy camera input.

The unlock/lock-night controls are buttons in **Misc → UNLOCK / LOCK NIGHTS**. Return to or reopen the game's level-selection screen after pressing one so the list refreshes.

## Important notes

- Back up your save before using progression buttons.
- The lock buttons only reset progression for the selected mode and leave gallery, media, plushies, dating progress, settings, and currency alone.
- Use this only in the single-player game. Game updates may require a rebuilt mod.

## Building from source

Requirements:

- Windows x64
- .NET 6 SDK
- IN HEAT with MelonLoader 0.7.3 installed and launched once

Extract `IHLFNModMenu-Source-Code.zip`. The project references generated assemblies from:

`E:\SteamLibrary\steamapps\common\IN HEAT\MelonLoader\Il2CppAssemblies`

If your game is installed elsewhere, edit every `HintPath` in `InHeatMenu.csproj` to match your game folder. Then run:

```powershell
dotnet build .\InHeatMenu.csproj -c Release
```

The result is placed at:

`bin\Release\net6.0\IHLFNModMenu.dll`

